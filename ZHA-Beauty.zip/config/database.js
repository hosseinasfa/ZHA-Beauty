module.exports = {
    url : process.env.DATABASE_URL,

}